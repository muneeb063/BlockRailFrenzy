using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public interface IAdNetwork 
{
    void Initialize();
    void ShowInterstitial();
    void ShowBanner();
    void ShowRewardedVideo();
}
