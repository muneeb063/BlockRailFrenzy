using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using GoogleMobileAds.Api;
[Serializable]

public enum BannerPosition
{
    TopLeft,
    Top,
    TopRight,
    BottomLeft,
    Bottom,
    BottomRight,
    None
}
public enum AdLoadingStatus
{
    NotLoaded,
    Loading,
    Loaded,
    NoInventory
}
public class AdmobAdsNetwork : MonoBehaviour,IAdNetwork
{
    public static AdLoadingStatus SB1Status = AdLoadingStatus.NotLoaded;
    public static AdLoadingStatus SB2Status = AdLoadingStatus.NotLoaded;
    public static AdLoadingStatus MBStatus = AdLoadingStatus.NotLoaded;

    public bool EnableTestAds;
    public bool LoggingEnabled;
    public bool useMediation;

    public GameObject LoadingPanel;
    public GameObject RewardedNotAvailableToast;
    public BannerPosition SmallBanner1Position = BannerPosition.TopLeft;
    public BannerPosition SmallBanner2Position = BannerPosition.TopRight;
    public BannerPosition MediumBannerPosition = BannerPosition.BottomLeft;

    public static bool isSB1Loaded = false;
    public static bool isSB2Loaded = false;
    public static bool isMBLoaded = false;
    private bool isAdsManagerInitialized = false;
    #region Banners
    private BannerView _SB1View;
    private int SB1IDNumber = 0;
    private BannerView _SB2View;
    private int SB2IDNumber = 0;
    #endregion
    #region MB
    private BannerView _MB;
    private int MBIDNumber = 0;
    #endregion
    private InterstitialAd _interstitialAd;
    private InterstitialAd _staticInterstitialAd;
    private RewardedInterstitialAd _RIAD;
    private RewardedAd _RAD;
    public delegate void RewardAfterAd();
    public delegate void FuncAfterInterstitial();
    private static RewardAfterAd notifyReward;
    private static FuncAfterInterstitial notifyInterstitial, notifyStaticInterstitial;
   // private CustomTimer timer;

    bool canShowAppOpen = true;

    bool canShowIAD = false;
    public void Initialize()
    {
        //timer = GetComponent<CustomTimer>();
        MobileAds.RaiseAdEventsOnUnityMainThread = true;
        MobileAds.Initialize((InitializationStatus initStatus) =>
        {
            isAdsManagerInitialized = true;
           // if (AdPurchaseStatus.isAdsAvailable())
           // {
                //Load_Medium_Banner();
                Load_Interstitial();
                Load_Static_Interstitial();
               // Load_App_Open();
            //}
            Load_Rewarded();
           // Load_Rewarded_Interstitial();
        });
    }
    AdPosition ConvertEnum(BannerPosition value)
    {
        switch (value)
        {
            case BannerPosition.TopLeft:
                return AdPosition.TopLeft;

            case BannerPosition.Top:
                return AdPosition.Top;

            case BannerPosition.TopRight:
                return AdPosition.TopRight;

            case BannerPosition.BottomLeft:
                return AdPosition.BottomLeft;

            case BannerPosition.Bottom:
                return AdPosition.Bottom;

            case BannerPosition.BottomRight:
                return AdPosition.BottomRight;


            default:
                throw new NotSupportedException();
        }
    }
    void EnableIADShowing()
    {
        canShowIAD = true;
    }
    private void TurnOffLoading()
    {
        if (LoadingPanel != null)
        {
            LoadingPanel.SetActive(false);
        }
    }
    #region Interstitial
    public void Load_Interstitial()
    {
       /* if (!AdPurchaseStatus.isAdsAvailable())
        {
            return;
        }*/
        if (Application.internetReachability != NetworkReachability.ReachableViaCarrierDataNetwork | Application.internetReachability != NetworkReachability.ReachableViaLocalAreaNetwork)
        {
            if (_interstitialAd != null)
            {
                DestroyIAD();
            }
            if (LoggingEnabled)
            {
                Debug.Log("GT>> Loading interstitial ad.");
            }
            AdRequest adRequest = new AdRequest();
            InterstitialAd.Load("ca-app-pub-3940256099942544/1033173712", adRequest, (InterstitialAd ad, LoadAdError error) =>
            {
                if (error != null)
                {
                    Debug.LogError("Interstitial ad failed to load an ad with error : " + error);
                    return;
                }
                if (ad == null)
                {
                    Debug.LogError("Unexpected error: Interstitial load event fired with null ad and null error.");
                    return;
                }
                if (LoggingEnabled)
                {
                    Debug.Log("GT>> Interstitial ad loaded with response : " + ad.GetResponseInfo());
                }
                _interstitialAd = ad;
                IADEventHandlers(ad);
            });
        }
        else
        {
            Debug.LogError("No internet connection. Cannot load ad.");
            return;
        }
    }
    public void Load_Static_Interstitial()
    {
       /* if (!AdPurchaseStatus.isAdsAvailable())
        {
            return;
        }*/
        if (Application.internetReachability != NetworkReachability.ReachableViaCarrierDataNetwork | Application.internetReachability != NetworkReachability.ReachableViaLocalAreaNetwork)
        {
            if (_staticInterstitialAd != null)
            {
                DestroySIAD();
            }
            if (LoggingEnabled)
            {
                Debug.Log("GT>> Loading static interstitial ad.");
            }
            AdRequest adRequest = new AdRequest();
            InterstitialAd.Load("ca-app-pub-3940256099942544/1033173712", adRequest, (InterstitialAd ad, LoadAdError error) =>
            {
                if (error != null)
                {
                    Debug.LogError("Static Interstitial ad failed to load an ad with error : " + error);
                    return;
                }
                if (ad == null)
                {
                    Debug.LogError("Unexpected error: static Interstitial load event fired with null ad and null error.");
                    return;
                }
                if (LoggingEnabled)
                {
                    Debug.Log("GT>> static Interstitial ad loaded with response : " + ad.GetResponseInfo());
                }
                _staticInterstitialAd = ad;
                IADEventHandlers(ad, true);
            });
        }
        else
        {
            Debug.LogError("No internet connection. Cannot load ad.");
            return;
        }
    }
    private void DestroyIAD()
    {
        if (_interstitialAd != null)
        {
            if (LoggingEnabled)
            {
                Debug.Log("GT>> Destroying interstitial ad.");
            }
            _interstitialAd.Destroy();
            //.StartTimer(TurnOffLoading);
            _interstitialAd = null;
        }
    }
    private void DestroySIAD()
    {
        if (_staticInterstitialAd != null)
        {
            if (LoggingEnabled)
            {
                Debug.Log("GT>> Destroying static interstitial ad.");
            }
            _staticInterstitialAd.Destroy();
           // timer.StartTimer(TurnOffLoading);
            _staticInterstitialAd = null;
        }
    }
    public void ShowInterstitial()
    {
        if (_interstitialAd != null && _interstitialAd.CanShowAd() /*&& canShowIAD*/)
        {
            canShowIAD = false;
            //Invoke(nameof(EnableIADShowing), 0.1f);
            if (LoggingEnabled)
            {
                Debug.Log("GT>> Showing interstitial ad.");
            }
           /* if (LoadingPanel != null)
                LoadingPanel.SetActive(true);*/
            _interstitialAd.Show();
            canShowAppOpen = false;
        }
        else if (!String.IsNullOrEmpty("ca-app-pub-3940256099942544/1033173712"))
        {
            Show_Static_Interstitial();
        }
    }
    public void Show_Interstitial(FuncAfterInterstitial f)
    {
        if (_interstitialAd != null && _interstitialAd.CanShowAd() && canShowIAD)
        {
            canShowIAD = false;
            Invoke(nameof(EnableIADShowing), 0.1f);
            if (LoggingEnabled)
            {
                Debug.Log("GT>> Showing interstitial ad.");
            }
            if (LoadingPanel != null)
                LoadingPanel.SetActive(true);
            _interstitialAd.Show();
            canShowAppOpen = false;
        }
        else if (!String.IsNullOrEmpty("ca-app-pub-3940256099942544/1033173712"))
        {
            Show_Static_Interstitial();
        }

        notifyInterstitial = f;
        if (notifyInterstitial != null)
        {
            notifyInterstitial();
        }
        notifyInterstitial = null;
    }

    public void Show_Static_Interstitial()
    {
        if (_staticInterstitialAd != null && _staticInterstitialAd.CanShowAd() && canShowIAD)
        {
            canShowIAD = false;
            Invoke(nameof(EnableIADShowing), 0.1f);
            if (LoggingEnabled)
            {
                Debug.Log("GT>> Showing static interstitial ad.");
            }
            if (LoadingPanel != null)
                LoadingPanel.SetActive(true);
            _staticInterstitialAd.Show();
            canShowAppOpen = false;
        }
    }
    public void Show_Static_Interstitial(FuncAfterInterstitial f)
    {
        if (_staticInterstitialAd != null && _staticInterstitialAd.CanShowAd() && canShowIAD)
        {
            canShowIAD = false;
            Invoke(nameof(EnableIADShowing), 0.1f);
            if (LoggingEnabled)
            {
                Debug.Log("GT>> Showing static interstitial ad.");
            }
            if (LoadingPanel != null)
                LoadingPanel.SetActive(true);
            _staticInterstitialAd.Show();
            canShowAppOpen = false;
        }
        notifyStaticInterstitial = f;
        if (notifyStaticInterstitial != null)
        {
            notifyStaticInterstitial();
        }
        notifyStaticInterstitial = null;
    }
    private void IADEventHandlers(InterstitialAd ad, bool isStaticInter = false)
    {
        ad.OnAdPaid += (AdValue adValue) =>
        {
            if (LoggingEnabled)
            {
                if (isStaticInter)
                {
                    Debug.Log(String.Format("GT>> static Interstitial ad paid {0} {1}.",
                    adValue.Value,
                    adValue.CurrencyCode));
                }
                else
                {
                    Debug.Log(String.Format("GT>> Interstitial ad paid {0} {1}.",
                    adValue.Value,
                    adValue.CurrencyCode));
                }
            }
        };
        ad.OnAdImpressionRecorded += () =>
        {
            if (LoggingEnabled)
            {
                if (isStaticInter)
                {
                    Debug.Log("GT>> static Interstitial ad recorded an impression.");
                }
                else
                {
                    Debug.Log("GT>> Interstitial ad recorded an impression.");
                }
            }
        };
        ad.OnAdClicked += () =>
        {
            if (LoggingEnabled)
            {
                if (isStaticInter)
                {
                    Debug.Log("GT>> static Interstitial ad was clicked.");
                }
                else
                {
                    Debug.Log("GT>> Interstitial ad was clicked.");
                }
            }
        };
        ad.OnAdFullScreenContentOpened += () =>
        {
            if (LoggingEnabled)
            {
                if (isStaticInter)
                {
                    Debug.Log("GT>> static Interstitial ad full screen content opened.");
                }
                else
                {
                    Debug.Log("GT>> Interstitial ad full screen content opened.");
                }
            }
        };
        ad.OnAdFullScreenContentClosed += () =>
        {
            if (LoggingEnabled)
            {
                if (isStaticInter)
                {
                    Debug.Log("GT>> static Interstitial ad full screen content closed.");
                }
                else
                {
                    Debug.Log("GT>> Interstitial ad full screen content closed.");
                }
            }
            canShowAppOpen = true;
            //timer.StartTimer(TurnOffLoading);
            if (isStaticInter)
            {
                Load_Static_Interstitial();
            }
            else
            {
                Load_Interstitial();
            }
        };
        ad.OnAdFullScreenContentFailed += (AdError error) =>
        {
           // timer.StartTimer(TurnOffLoading);
            if (LoggingEnabled)
            {
                if (isStaticInter)
                {
                    Debug.LogError("GT>> static Interstitial ad failed to open full screen content with error : "
               + error);
                }
                else
                {
                    Debug.LogError("GT>> Interstitial ad failed to open full screen content with error : "
                    + error);
                }
            }
        };
    }
    #endregion
    #region SB1
    public void Show_SmallBanner_1()
    {
      /*  if (!AdPurchaseStatus.isAdsAvailable() || !isAdsManagerInitialized)
        {
            return;
        }*/
        if (_SB1View != null)
        {
            _SB1View.Show();
            _SB1View.SetPosition(AdPosition.Bottom);
        }
    }
    private void CreateSB1View()
    {
        if (_SB1View != null)
        {
            DestroySB1();
        }
        if (LoggingEnabled)
        {
            Debug.Log("GT>> CreateSB1ViewFunction");
        }
        _SB1View = new BannerView("ca-app-pub-3940256099942544/6300978111", AdSize.Banner, AdPosition.Bottom);
        SB1Events();
    }
    public bool isReady_SmallBanner_1()
    {
        return isSB1Loaded;
    }

    public void ShowBanner()
    {
        if (/*!AdPurchaseStatus.isAdsAvailable() ||*/ isReady_SmallBanner_1() || SB1Status == AdLoadingStatus.Loading || SmallBanner1Position == BannerPosition.None)
        {
            return;
        }
        if (Application.internetReachability == NetworkReachability.ReachableViaCarrierDataNetwork | Application.internetReachability == NetworkReachability.ReachableViaLocalAreaNetwork)
        {
            if (LoggingEnabled)
            {
                Debug.Log("GT>> CreateSB1View");
            }
            CreateSB1View();
            AdRequest adRequest = new AdRequest();
            _SB1View.LoadAd(adRequest);
            if (LoggingEnabled)
            {
                Debug.Log("GT>> Load SB1.");
            }
        }
    }
    public void Hide_SmallBanner_1()
    {
        if (_SB1View != null)
        {
            _SB1View.Hide();
            if (LoggingEnabled)
            {
                Debug.Log("GT>> Hide SB1.");
            }
        }
    }
    private void SB1Events()
    {
        _SB1View.OnBannerAdLoaded += () =>
        {
            if (LoggingEnabled)
            {
                Debug.Log("GT>> Banner1 view loaded an ad with response : "
                    + _SB1View.GetResponseInfo());
            }
            SB1Status = AdLoadingStatus.Loaded;
            isSB1Loaded = true;
        };
        _SB1View.OnBannerAdLoadFailed += (LoadAdError error) =>
        {
            if (LoggingEnabled)
            {
                Debug.Log("GT>> Left Banner view failed to load an ad with error : "
                    + error);
            }
            SB1Status = AdLoadingStatus.NoInventory;
            isSB1Loaded = false;
           /* if (LoggingEnabled)
            {
                Debug.Log("GT>> ADMOB_IDS.ADMOD_SB_Left__ID.Count" + ADMOB_IDS.ADMOB_SB1_IDs.Count);
            }*/
            /*if (SB1IDNumber < ADMOB_IDS.ADMOB_SB1_IDs.Count - 1)
            {
                SB1IDNumber++;
                ShowBanner();
                if (LoggingEnabled)
                {
                    Debug.Log("GT>> LoadagainAfterFail");
                }
            }*/
           /* else
            {
                SB1IDNumber = 0;
                if (LoggingEnabled)
                {
                    Debug.Log("GT>> No More SB1 IDS");
                }
            }*/
        };
    }
    private void DestroySB1()
    {
        if (_SB1View != null)
        {
            if (LoggingEnabled)
            {
                Debug.Log("GT>> Destroying banner ad.");
            }
            _SB1View.Destroy();
            _SB1View = null;
        }
    }
    #endregion
    #region BothRewarded
    private void DestroyRAD()
    {
        if (_RAD != null)
        {
            if (LoggingEnabled)
            {
                Debug.Log("GT>> Destroying rewarded ad.");
            }
            _RAD.Destroy();
          //  timer.StartTimer(TurnOffLoading);
            _RAD = null;
        }
    }
    public void Load_Rewarded()
    {
        if (_RAD != null)
        {
            DestroyRAD();
        }
        if (LoggingEnabled)
        {
            Debug.Log("GT>> Loading rewarded ad.");
        }
        AdRequest adRequest = new AdRequest();
        RewardedAd.Load("ca-app-pub-3940256099942544/5224354917", adRequest, (RewardedAd ad, LoadAdError error) =>
        {
            if (error != null)
            {
                Debug.LogError("GT>> Rewarded ad failed to load an ad with error : " + error);
                return;
            }
            if (ad == null)
            {
                Debug.LogError("GT>> Unexpected error: Rewarded load event fired with null ad and null error.");
                return;
            }
            if (LoggingEnabled)
            {
                Debug.Log("GT>> Rewarded ad loaded with response : " + ad.GetResponseInfo());
            }
            _RAD = ad;
            //RADEventHandlers(ad);
        });
    }
    public void ShowRewardedVideo(/*RewardAfterAd r*/)
    {
        if (_RAD != null || _RAD.CanShowAd())
        {
            Show_Rewarded(/*r*/);
            Load_Rewarded();
        }/*
        else if (_RIAD != null && _RIAD.CanShowAd())
        {
            Show_Rewarded_Interstitial(r);
        }*/
       /* else
        {
            RewardedNotAvailableToast.SetActive(true);
        }*/
    }
    public void Show_Rewarded(/*RewardAfterAd rewardAfterAd*/)
    {
       // notifyReward = rewardAfterAd;
        if (_RAD != null && _RAD.CanShowAd())
        {
            if (LoggingEnabled)
            {
                Debug.Log("GT>> Showing rewarded ad.");
            }
           /* if (LoadingPanel != null)
                LoadingPanel.SetActive(true);*/
            _RAD.Show((Reward reward) =>
            {
                if (LoggingEnabled)
                {
                    Debug.Log(String.Format("GT>> Rewarded ad granted a reward: {0} {1}",
                                            reward.Amount,
                                            reward.Type));
                }
              /*  if (notifyReward != null)
                {
                    notifyReward();
                }
                notifyReward = null;*/
            });
            canShowAppOpen = false;
        }
    }
    #endregion
}
