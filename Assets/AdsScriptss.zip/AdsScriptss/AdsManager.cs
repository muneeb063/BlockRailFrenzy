using System.Collections;
using System.Collections.Generic;
using System.Xml.Serialization;
using UnityEngine;
using Watermelon;

public enum AdNetwork
{
  None,
  Admob,
  UnityAds
}
public class AdsManager : MonoBehaviour
{
    private static AdsManager instance;
    public AdNetwork adNetwork = AdNetwork.None;
    public IAdNetwork iadNetwork;
    
    // Start is called before the first frame update
    public static AdsManager Instance
    {
        get => GetInstance();
    }

    public static AdsManager GetInstance()
    {
        if (instance != null)
        {
            return instance;
        }
        else
        {
            return new AdsManager();
        }
    }
    public void Initialize(AdNetwork adNetwork)
    {
        switch (adNetwork) { 
        case AdNetwork.Admob:
                iadNetwork = new AdmobScript();
                break;
        case AdNetwork.UnityAds:
                iadNetwork =new UnityAdsManager();
                break;
            default:
                break;
        }

        iadNetwork.Initialize();
        }
    private void Awake()
    {
        if (instance == null)
        {
            instance = this;
        }
        Initialize(adNetwork);
        if (PlayerPrefs.GetInt("IsfirstTime") == 0)
        {
            PlayerPrefs.SetInt("IsfirstTime", 1);
            Log_FB_Event("First_Session");
        }
        else
        {
            Log_FB_Event("Session_Start");
        }
        DontDestroyOnLoad(this);
    }
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
    public void ShowBanner()
    {
        iadNetwork.ShowBanner();
    }
    public void ShowInterstitial()
    {
        iadNetwork.ShowInterstitial();
    }
    public void ShowRewarded()
    {
        iadNetwork.ShowRewardedVideo();
    }
    public void Log_FB_Event(string s)
    {
        if (Firebase_Initializer.IsFirebaseReady)
        {
            Firebase.Analytics.FirebaseAnalytics.LogEvent(s);
        }
    }
}
