using UnityEngine;
using UnityEngine.Advertisements;
using System;
using System.Collections;
using System.Collections.Generic;
public class UnityAdsManager : MonoBehaviour, IAdNetwork
{
    [SerializeField] private string androidGameId = "YOUR_ANDROID_GAME_ID";
    [SerializeField] private bool testMode = true;

    private string bannerPlacementId = "BannerAd";
    private string interstitialPlacementId = "InterstitialAd";
    private string rewardedVideoPlacementId = "RewardedAd";

    void Start()
    {
        

    }
    public void Initialize()
    {
        Advertisement.Initialize(androidGameId, testMode);
    }
    #region Banner Ads
    public void ShowBanner()
    {
        
            Advertisement.Banner.SetPosition(UnityEngine.Advertisements.BannerPosition.BOTTOM_CENTER);
            Advertisement.Banner.Show(bannerPlacementId);
        
       
    }

    public void HideBannerAd()
    {
        Advertisement.Banner.Hide();
    }
    #endregion

    #region Interstitial Ads
    public void ShowInterstitial()
    {
            Advertisement.Show(interstitialPlacementId);
     
    }
    #endregion

    #region Rewarded Video Ads
    public void ShowRewardedVideo()
    {
            Advertisement.Show(rewardedVideoPlacementId, new ShowOptions
            {
              // resultCallback = HandleRewardedAdResult
            });
    }

    private void HandleRewardedAdResult(ShowResult result)
    {
        switch (result)
        {
            case ShowResult.Finished:
                Debug.Log("Player watched the entire ad. Reward them!");
                // Grant the reward here.
                break;
            case ShowResult.Skipped:
                Debug.Log("Player skipped the ad. No reward given.");
                break;
            case ShowResult.Failed:
                Debug.LogError("Ad failed to show.");
                break;
        }
    }
    #endregion
}
