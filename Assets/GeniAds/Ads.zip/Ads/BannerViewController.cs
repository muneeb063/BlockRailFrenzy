using System;
using UnityEngine;
using GoogleMobileAds.Api;
using System.Collections.Generic;
using GameAnalyticsSDK;
namespace GoogleMobileAds.Sample
{
    [AddComponentMenu("GoogleMobileAds/Samples/BannerViewController")]
    public class BannerViewController : MonoBehaviour
    {
        private const string _adUnitId = "ca-app-pub-8411576398660554/2126117849";
        //private const string _adUnitId = "ca-app-pub-3940256099942544/6300978111"; //Test
        public BannerView _bannerView;
        [SerializeField] UnityPaidEvent UNITY_PAID_EVENTS;
        protected AdLoadingStatus bAdStatus = AdLoadingStatus.NotLoaded;
        public void CreateBannerView()
        {
            Debug.Log("Creating banner view.");

            if (_bannerView != null)
            {
                DestroyAd();
            }
            bAdStatus = AdLoadingStatus.NotLoaded;

            _bannerView = new BannerView(_adUnitId, AdSize.Banner, AdPosition.Top);

            ListenToAdEvents();

            Debug.Log("Banner view created.");
        }
        public void LoadAd()
        {
            if (_bannerView == null)
            {
                CreateBannerView();
            }
            AdmobGA_Helper.GA_Log(AdmobGAEvents.LoadBannerAd);
            var adRequest = new AdRequest();
            bAdStatus = AdLoadingStatus.Loading;
            GameAnalytics.NewAdEvent(GAAdAction.Request, GAAdType.Banner, "admob", "BannerPlacement");
            Debug.Log("Loading banner ad.");
            _bannerView.LoadAd(adRequest);
        }
        public void ShowAd()
        {
            if (_bannerView != null)
            {
                Debug.Log("Showing banner view.");
                _bannerView.Show();
            }
        }
        public void HideAd()
        {
            if (_bannerView != null)
            {
                Debug.Log("Hiding banner view.");
                _bannerView.Hide();
            }
        }
        public void DestroyAd()
        {
            if (_bannerView != null)
            {
                Debug.Log("Destroying banner view.");
                _bannerView.Destroy();
                _bannerView = null;
            }
        }
        public void LogResponseInfo()
        {
            if (_bannerView != null)
            {
                var responseInfo = _bannerView.GetResponseInfo();
                if (responseInfo != null)
                {
                    UnityEngine.Debug.Log(responseInfo);
                }
            }
        }
        private void ListenToAdEvents()
        {
            _bannerView.OnBannerAdLoaded += () =>
            {
                Debug.Log("Banner view loaded an ad with response : "
                    + _bannerView.GetResponseInfo());

                AdmobGA_Helper.GA_Log(AdmobGAEvents.BannerAdLoaded);
                GameAnalytics.NewAdEvent(GAAdAction.Loaded, GAAdType.Banner, "admob", "BannerPlacement");
                AdmobGA_Helper.GA_Log(AdmobGAEvents.BannerAdDisplayed);
                GameAnalytics.NewAdEvent(GAAdAction.Show, GAAdType.Banner, "admob", "BannerPlacement");
            };
            _bannerView.OnBannerAdLoadFailed += (LoadAdError error) =>
            {
                Debug.LogError("Banner view failed to load an ad with error : " + error);
                if (Application.internetReachability == NetworkReachability.NotReachable)
                {
                    return;
                }
                bAdStatus = AdLoadingStatus.NoInventory;
                AdmobGA_Helper.GA_Log(AdmobGAEvents.BannerAdNoInventory);

                Invoke(nameof(LoadAd), 2);
            };
            _bannerView.OnAdPaid += (AdValue adValue) =>
            {
                Debug.Log(String.Format("Banner view paid {0} {1}.",
                    adValue.Value,
                    adValue.CurrencyCode));
                UNITY_PAID_EVENTS.Banner_OnPaidEvent(adValue);

            };
            _bannerView.OnAdImpressionRecorded += () =>
            {
                Debug.Log("Banner view recorded an impression.");
            };
            _bannerView.OnAdClicked += () =>
            {
                Debug.Log("Banner view was clicked.");
                bAdStatus = AdLoadingStatus.NotLoaded;
                AdmobGA_Helper.GA_Log(AdmobGAEvents.BannerAdClicked);
            };
            _bannerView.OnAdFullScreenContentOpened += () =>
            {
                Debug.Log("Banner view full screen content opened.");
            };
            _bannerView.OnAdFullScreenContentClosed += () =>
            {
                Debug.Log("Banner view full screen content closed.");
                AdmobGA_Helper.GA_Log(AdmobGAEvents.BannerAdClosed);
                bAdStatus = AdLoadingStatus.NotLoaded;
                Invoke(nameof(LoadAd), 2);
            };
        }
    }
}
