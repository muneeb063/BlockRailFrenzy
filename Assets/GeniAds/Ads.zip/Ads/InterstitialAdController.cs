using System;
using UnityEngine;
using GoogleMobileAds.Api;
using System.Collections.Generic;
using GameAnalyticsSDK;

namespace GoogleMobileAds.Sample
{
    [AddComponentMenu("GoogleMobileAds/Samples/InterstitialAdController")]
    public class InterstitialAdController : MonoBehaviour
    {
        private const string _adUnitId = "ca-app-pub-8411576398660554/9891823578";
        //private const string _adUnitId = "ca-app-pub-3940256099942544/1033173712"; //Test
        public InterstitialAd _interstitialAd;
        private string latestInterstitialError;
        [SerializeField] UnityPaidEvent UNITY_PAID_EVENTS;
        protected AdLoadingStatus iAdStatus = AdLoadingStatus.NotLoaded;
        public void LoadAd()
        {
            if (_interstitialAd != null)
            {
                DestroyAd();
            }

            Debug.Log("Loading interstitial ad.");

            var adRequest = new AdRequest();
            AdmobGA_Helper.GA_Log(AdmobGAEvents.LoadInterstitialAd);
            InterstitialAd.Load(_adUnitId, adRequest, (InterstitialAd ad, LoadAdError error) =>
            {
                iAdStatus = AdLoadingStatus.Loading;
                GameAnalytics.NewAdEvent(GAAdAction.Request, GAAdType.Interstitial, "admob", "InterstitialPlacement");
                if (error != null || ad == null)
                {
                    Debug.Log("Interstitial ad failed to load with error: " + error.GetMessage());
                    HandleOnAdFailedToLoad(error);
                    return;
                }
                iAdStatus = AdLoadingStatus.Loaded;
                AdmobGA_Helper.GA_Log(AdmobGAEvents.InterstitialAdLoaded);
                GameAnalytics.NewAdEvent(GAAdAction.Loaded, GAAdType.Interstitial, "admob", "InterstitialPlacement");

                Debug.Log("Interstitial ad loaded with response : " + ad.GetResponseInfo());
                _interstitialAd = ad;
                RegisterEventHandlers(ad);

            });
        }
        
        public void ShowAd()
        {
            if (_interstitialAd != null && _interstitialAd.CanShowAd())
            {
                Debug.Log("Showing interstitial ad.");
                AdmobGA_Helper.GA_Log(AdmobGAEvents.ShowInterstitialAd);
                AdmobGA_Helper.GA_Log(AdmobGAEvents.InterstitialAdWillDisplay);
                _interstitialAd.Show();
            }
            else
            {
                Debug.LogError("Interstitial ad is not ready yet.");
                GameAnalytics.NewAdEvent(GAAdAction.FailedShow, GAAdType.Interstitial, "admob", "InterstitialPlacement", getLatestAdError(this.latestInterstitialError));
                LoadAd();
            }
        }
        public void DestroyAd()
        {
            if (_interstitialAd != null)
            {
                Debug.Log("Destroying interstitial ad.");
                _interstitialAd.Destroy();
                _interstitialAd = null;
            }

        }
        public void LogResponseInfo()
        {
            if (_interstitialAd != null)
            {
                var responseInfo = _interstitialAd.GetResponseInfo();
                UnityEngine.Debug.Log(responseInfo);
            }
        }

        private void RegisterEventHandlers(InterstitialAd ad)
        {
            ad.OnAdPaid += (AdValue adValue) =>
            {
                Debug.Log(String.Format("Interstitial ad paid {0} {1}.",
                    adValue.Value,
                    adValue.CurrencyCode));
                UNITY_PAID_EVENTS.InterstitialAd_OnPaidEvent(adValue);
            };
            ad.OnAdImpressionRecorded += () =>
            {
                Debug.Log("Interstitial ad recorded an impression.");
                AdmobGA_Helper.GA_Log(AdmobGAEvents.InterstitialAdClicked);
                GameAnalytics.NewAdEvent(GAAdAction.Clicked, GAAdType.Interstitial, "admob", "InterstitialPlacement");
            };
            ad.OnAdClicked += () =>
            {
                Debug.Log("Interstitial ad was clicked.");
            };
            ad.OnAdFullScreenContentOpened += () =>
            {
                Debug.Log("Interstitial ad full screen content opened.");
                iAdStatus = AdLoadingStatus.NotLoaded;
                AdmobGA_Helper.GA_Log(AdmobGAEvents.InterstitialAdDisplayed);
                GameAnalytics.NewAdEvent(GAAdAction.Show, GAAdType.Interstitial, "admob", "InterstitialPlacement");

            };
            ad.OnAdFullScreenContentClosed += () =>
            {
                Debug.Log("Interstitial ad full screen content closed.");
                AdmobGA_Helper.GA_Log(AdmobGAEvents.InterstitialAdClosed);
               // GameAnalytics.NewAdEvent(GAAdAction.Closed, GAAdType.Interstitial, "admob", "InterstitialPlacement");
                iAdStatus = AdLoadingStatus.NotLoaded;

                LoadAd();
            };
            ad.OnAdFullScreenContentFailed += (AdError error) =>
            {
                Debug.LogError("Interstitial ad failed to open full screen content with error : "
                    + error);
                LoadAd();
            };
        }

        private GAAdError getLatestAdError(string error)
        {
            GAAdError result = GAAdError.Unknown;
            switch (error)
            {
                case "Unknown":
                    result = GAAdError.Unknown;
                    break;
                case "Offline":
                    result = GAAdError.Offline;
                    break;
                case "NoFill":
                    result = GAAdError.NoFill;
                    break;
                case "InternalError":
                    result = GAAdError.InternalError;
                    break;
                case "InvalidRequest":
                    result = GAAdError.InvalidRequest;
                    break;
                case "UnableToPrecached":
                    result = GAAdError.UnableToPrecache;
                    break;
                default:
                    result = GAAdError.Unknown;
                    break;
            }

            return result;
        }
        public void HandleOnAdFailedToLoad(LoadAdError loadError)
        {
            latestInterstitialError = loadError.GetMessage().ToString();
            iAdStatus = AdLoadingStatus.NoInventory;
            AdmobGA_Helper.GA_Log(AdmobGAEvents.InterstitialAdNoInventory);
        }
    }
}
