using System;
using UnityEngine;
using GoogleMobileAds.Api;
using System.Collections.Generic;
using GameAnalyticsSDK;
using Firebase.Analytics;
namespace GoogleMobileAds.Sample
{
    [AddComponentMenu("GoogleMobileAds/Samples/RewardedAdController")]
    public class RewardedAdController : MonoBehaviour
    {
        private const string _adUnitId = "ca-app-pub-8411576398660554/7265660231"; 
        //private const string _adUnitId = "ca-app-pub-3940256099942544/5224354917"; //Test

        public RewardedAd _rewardedAd;
        [SerializeField] UnityPaidEvent UNITY_PAID_EVENTS;
        protected AdLoadingStatus rAdStatus = AdLoadingStatus.NotLoaded;
        private string latestRewardedErrorMessage;
        [HideInInspector] public string PlacementforAds;
        private string currentRewardedVideoPlacement = "RewardedPlacementTimer";

        public bool CanShowRewarded()
        {
            return _rewardedAd.CanShowAd();
        }
        public void LoadAd()
        {
            AdmobGA_Helper.GA_Log(AdmobGAEvents.LoadRewardedAd);
            GameAnalytics.NewAdEvent(GAAdAction.Request, GAAdType.RewardedVideo, "admob", "RewardedPlacement");
            if (_rewardedAd != null)
            {
                DestroyAd();
            }

            Debug.Log("Loading rewarded ad.");

            var adRequest = new AdRequest();
            rAdStatus = AdLoadingStatus.Loading;

            RewardedAd.Load(_adUnitId, adRequest, (RewardedAd ad, LoadAdError error) =>
            {
                if (error != null || ad == null)
                {
                    Debug.LogError("Rewarded ad failed to load an ad " +
                                   "with error : " + error);
                    rAdStatus = AdLoadingStatus.NoInventory;
                    AdmobGA_Helper.GA_Log(AdmobGAEvents.RewardedAdNoInventory);
                    latestRewardedErrorMessage = error.ToString();
                    return;
                }

                Debug.Log("Rewarded ad loaded with response : " + ad.GetResponseInfo());
                _rewardedAd = ad;
                rAdStatus = AdLoadingStatus.Loaded;
                AdmobGA_Helper.GA_Log(AdmobGAEvents.RewardedAdLoaded);
                GameAnalytics.NewAdEvent(GAAdAction.Loaded, GAAdType.RewardedVideo, "admob", "Rewardedplacement");
                RegisterEventHandlers(ad);


            });
        }
        public void ShowAd(Action RewardedAction)
        {
            if (_rewardedAd != null && _rewardedAd.CanShowAd())
            {
                Debug.Log("Showing rewarded ad.");
                _rewardedAd.Show((Reward reward) =>
                {
                    RewardedAction?.Invoke();
                });
            }
            else
            {
                LoadAd();
            }
        }
        public void DestroyAd()
        {
            if (_rewardedAd != null)
            {
                Debug.Log("Destroying rewarded ad.");
                _rewardedAd.Destroy();
                _rewardedAd = null;
            }
        }
        public void LogResponseInfo()
        {
            if (_rewardedAd != null)
            {
                var responseInfo = _rewardedAd.GetResponseInfo();
                UnityEngine.Debug.Log(responseInfo);
            }
        }
        private void RegisterEventHandlers(RewardedAd ad)
        {
            ad.OnAdPaid += (AdValue adValue) =>
            {
                Debug.Log(String.Format("Rewarded ad paid {0} {1}.",
                    adValue.Value,
                    adValue.CurrencyCode));
                UNITY_PAID_EVENTS.RewardedAd_OnPaidEvent(adValue);
            };
            ad.OnAdImpressionRecorded += () =>
            {
                Debug.Log("Rewarded ad recorded an impression.");
            };
            ad.OnAdClicked += () =>
            {
                GameAnalytics.NewAdEvent(GAAdAction.Clicked, GAAdType.RewardedVideo, "admob", currentRewardedVideoPlacement);
                Debug.Log("Rewarded ad was clicked.");
            };
            ad.OnAdFullScreenContentOpened += () =>
            {
                Debug.Log("Rewarded ad full screen content opened.");
                rAdStatus = AdLoadingStatus.NotLoaded;
                FirebaseLogRadsEvent(RewardedAdStatus.rewarded_opt_in, Constant.PlacementforAds, 0, "");
                currentRewardedVideoPlacement = null;
                currentRewardedVideoPlacement = "RewardedPlacementTimer";
                AdmobGA_Helper.GA_Log(AdmobGAEvents.RewardedAdDisplayed);
                GameAnalytics.NewAdEvent(GAAdAction.Show, GAAdType.RewardedVideo, "admob", currentRewardedVideoPlacement);
                GameAnalytics.StartTimer(currentRewardedVideoPlacement);
            };
            ad.OnAdFullScreenContentClosed += () =>
            {
                Debug.Log("Rewarded ad full screen content closed.");
                rAdStatus = AdLoadingStatus.NotLoaded;
                AdmobGA_Helper.GA_Log(AdmobGAEvents.RewardedAdClosed);
                //GameAnalytics.NewAdEvent(GAAdAction.Closed, GAAdType.RewardedVideo, "admob", currentRewardedVideoPlacement);
                if (currentRewardedVideoPlacement != null)
                {
                    long elapsedTime = GameAnalytics.StopTimer(currentRewardedVideoPlacement);
                    currentRewardedVideoPlacement = null;
                }

                Invoke(nameof(LoadAd), 2f);
            };
            ad.OnAdFullScreenContentFailed += (AdError error) =>
            {
                Debug.LogError("Rewarded ad failed to open full screen content with error : "
                    + error);
                rAdStatus = AdLoadingStatus.NotLoaded;
                FirebaseLogRadsEvent(RewardedAdStatus.rewarded_failed, Constant.PlacementforAds, 0, "");
            };
        }
        public static void FirebaseLogRadsEvent(RewardedAdStatus rewardedAdStatus, string placement, int chapter, string sub_chapter)
        {
            FirebaseAnalytics.LogEvent(rewardedAdStatus.ToString(),
                                             new Parameter[] {
                        new Parameter("placement", placement),
                        new Parameter("chapter",chapter),
                        new Parameter("sub_chapter", sub_chapter)
                                             });
        }
    }
}
